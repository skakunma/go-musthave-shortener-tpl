---
name: Other issues
about: Any issue that is not a bug or a feature request
title: ''
labels: ''
assignees: ''

---

Please describe the issue in detail. If this is a question about how to use pgx please use discussions instead.
