package pgproto3

const MaxMessageBodyLen = maxMessageBodyLen
