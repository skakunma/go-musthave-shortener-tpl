create table tasks (
  id serial primary key,
  description text not null
);
